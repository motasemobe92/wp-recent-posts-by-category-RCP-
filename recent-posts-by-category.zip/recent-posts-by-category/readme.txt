=== Recent Posts by Category (RCP) ===
Contributors: uptixa
Tags: category, posts
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
A plugin to display recent posts from a specific category with a modern design using Bootstrap and jQuery.

== Installation ==
1. Upload the plugin to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure plugin settings from the Settings menu.

== Frequently Asked Questions ==
= How do I install the plugin? =
You can install the plugin from the WordPress dashboard under "Plugins" > "Add New".

== Changelog ==
= 1.0 =
* Initial release.
