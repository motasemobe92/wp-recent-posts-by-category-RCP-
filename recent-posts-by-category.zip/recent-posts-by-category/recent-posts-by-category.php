<?php
/*
Plugin Name: Recent Posts by Category (RCP)
Description: A plugin to display recent posts from a specific category with a modern design using Bootstrap and jQuery.
Version: 1.0
Author: uptixa
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// Enqueue Scripts and Styles (Bootstrap, jQuery, Custom CSS/JS)
function rpc_enqueue_scripts() {
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_script('jquery');
    wp_enqueue_style('rpc-custom-plugin-css', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('rpc-custom-plugin-js', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), null, true);

    wp_localize_script('rpc-custom-plugin-js', 'rpc_loadmore_params', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'posts_per_page' => get_option('rpc_posts_per_page', 5),
        'category' => get_option('rpc_category', 'news'),
        'order_by' => get_option('rpc_order_by', 'date'),
        'layout' => get_option('rpc_layout', 'grid')
    ));
}
add_action('wp_enqueue_scripts', 'rpc_enqueue_scripts');



// Shortcode to Display Recent Posts from a Specific Category
function rpc_recent_posts_by_category($atts) {
    // Default attributes for the shortcode
    $atts = shortcode_atts(
        array(
            'category' => 'news', // Default category
            'posts_per_page' => 5, // Default number of posts
            'layout' => 'grid', // Default layout
            'order_by' => 'date', // Default sorting by date
            'show_image' => true, // Show post image by default
            'show_excerpt' => true, // Show excerpt by default
            'rtl' => false, // Default is left-to-right
        ), $atts, 'recent_posts'
    );

    // Sanitize and parse inputs
    $category = sanitize_text_field($atts['category']);
    $posts_per_page = intval($atts['posts_per_page']);
    $layout = sanitize_text_field($atts['layout']);
    $order_by = sanitize_text_field($atts['order_by']);
    $show_image = filter_var($atts['show_image'], FILTER_VALIDATE_BOOLEAN);
    $show_excerpt = filter_var($atts['show_excerpt'], FILTER_VALIDATE_BOOLEAN);
    $rtl = filter_var($atts['rtl'], FILTER_VALIDATE_BOOLEAN);

    // Query for recent posts based on the category
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => $posts_per_page,
        'category_name' => $category,
        'orderby' => $order_by,
        'order' => 'DESC',
    );

    $query = new WP_Query($args);

    // Prepare HTML output for posts
    if ($query->have_posts()) {
        ob_start();
        ?>
        <div class="container my-5 <?php echo $rtl ? 'rtl' : ''; ?>">
            <div class="row <?php echo $layout === 'masonry' ? 'masonry-layout' : ''; ?>">
                <?php while ($query->have_posts()): $query->the_post(); ?>
                    <div class="col-12 <?php echo $layout === 'grid' ? 'col-sm-6 col-md-4' : 'mb-4'; ?> post-item">
                        <a href="<?php the_permalink(); ?>" class="card-link">
                            <div class="card shadow-sm">
                                <?php if ($show_image && has_post_thumbnail()): ?>
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medium')); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php the_title(); ?></h5>
                                    <?php if ($show_excerpt): ?>
                                        <p class="card-text"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 20)); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>

        </div>
        <?php
        wp_reset_postdata();
        return ob_get_clean();
    } else {
        return '<p>No posts found in this category.</p>';
    }
}
add_shortcode('recent_posts', 'rpc_recent_posts_by_category');

// Plugin settings page for the admin panel
function rpc_plugin_settings_page_content() {
    ?>
    <div class="wrap">
        <h1><?php _e('Recent Posts by Category Settings', 'rpc-plugin'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('rpc_plugin_settings_group');
            do_settings_sections('rpc-plugin-settings');
            ?>
            <table class="form-table">
                <tr>
                    <th><label for="rpc_category"><?php _e('Select Category', 'rpc-plugin'); ?></label></th>
                    <td>
                        <?php
                        $categories = get_categories();
                        $selected_category = get_option('rpc_category', 'news');
                        ?>
                        <select name="rpc_category" id="rpc_category" onchange="generate_shortcode()">
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo esc_attr($category->slug); ?>" <?php selected($selected_category, $category->slug); ?>>
                                    <?php echo esc_html($category->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th><label for="rpc_show_image"><?php _e('Show Post Image?', 'rpc-plugin'); ?></label></th>
                    <td>
                        <input type="checkbox" id="rpc_show_image" name="rpc_show_image" value="1" <?php checked(get_option('rpc_show_image', 1), 1); ?> />
                        <label for="rpc_show_image"><?php _e('Display post image in the grid', 'rpc-plugin'); ?></label>
                    </td>
                </tr>

                <tr>
                    <th><label for="rpc_posts_per_page"><?php _e('Number of Posts to Display', 'rpc-plugin'); ?></label></th>
                    <td>
                        <input type="number" id="rpc_posts_per_page" name="rpc_posts_per_page" value="<?php echo esc_attr(get_option('rpc_posts_per_page', 5)); ?>" min="1" />
                    </td>
                </tr>

                <!-- Layout Option -->
                <tr>
                    <th><label for="rpc_layout"><?php _e('Select Layout', 'rpc-plugin'); ?></label></th>
                    <td>
                        <select name="rpc_layout" id="rpc_layout" onchange="generate_shortcode()">
                            <option value="grid" <?php selected(get_option('rpc_layout', 'grid'), 'grid'); ?>><?php _e('Grid Layout', 'rpc-plugin'); ?></option>
                            <option value="list" <?php selected(get_option('rpc_layout', 'grid'), 'list'); ?>><?php _e('List Layout', 'rpc-plugin'); ?></option>
                            <option value="masonry" <?php selected(get_option('rpc_layout', 'grid'), 'masonry'); ?>><?php _e('Masonry Layout', 'rpc-plugin'); ?></option>
                        </select>
                    </td>
                </tr>

                <!-- Post Sorting -->
                <tr>
                    <th><label for="rpc_order_by"><?php _e('Post Sorting', 'rpc-plugin'); ?></label></th>
                    <td>
                        <select name="rpc_order_by" id="rpc_order_by" onchange="generate_shortcode()">
                            <option value="date" <?php selected(get_option('rpc_order_by', 'date'), 'date'); ?>><?php _e('Sort by Date', 'rpc-plugin'); ?></option>
                            <option value="title" <?php selected(get_option('rpc_order_by', 'date'), 'title'); ?>><?php _e('Sort by Title', 'rpc-plugin'); ?></option>
                            <option value="comment_count" <?php selected(get_option('rpc_order_by', 'date'), 'comment_count'); ?>><?php _e('Sort by Comment Count', 'rpc-plugin'); ?></option>
                        </select>
                    </td>
                </tr>

                <!-- RTL Support -->
                <tr>
                    <th><label for="rpc_rtl"><?php _e('Enable RTL Support', 'rpc-plugin'); ?></label></th>
                    <td>
                        <input type="checkbox" id="rpc_rtl" name="rpc_rtl" value="1" <?php checked(get_option('rpc_rtl', 0), 1); ?> />
                        <label for="rpc_rtl"><?php _e('Enable Right-to-Left support for languages', 'rpc-plugin'); ?></label>
                    </td>
                </tr>
            </table>

         <hr>

            <h3>Generated Shortcode:</h3>
            <textarea rows="4" cols="50" readonly>
[recent_posts category="<?php echo esc_attr(get_option('rpc_category', 'news')); ?>" posts_per_page="<?php echo esc_attr(get_option('rpc_posts_per_page', 5)); ?>" layout="<?php echo esc_attr(get_option('rpc_layout', 'grid')); ?>" order_by="<?php echo esc_attr(get_option('rpc_order_by', 'date')); ?>" show_image="<?php echo esc_attr(get_option('rpc_show_image', '1')); ?>"]
            </textarea>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Save plugin settings
function rpc_plugin_register_settings() {
    register_setting('rpc_plugin_settings_group', 'rpc_category', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_posts_per_page', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_layout', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_order_by', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_show_image', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_show_excerpt', 'sanitize_text_field' );
    register_setting('rpc_plugin_settings_group', 'rpc_rtl', 'sanitize_text_field' );
}

add_action('admin_init', 'rpc_plugin_register_settings');

// Add the plugin settings menu
function rpc_plugin_settings_menu() {
    add_menu_page('Recent Posts by Category', 'RPC Settings', 'manage_options', 'rpc-plugin-settings', 'rpc_plugin_settings_page_content');
}
add_action('admin_menu', 'rpc_plugin_settings_menu');
