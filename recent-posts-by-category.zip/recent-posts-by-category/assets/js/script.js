//JavaScript for smooth scrolling on Read More button click
jQuery(document).ready(function($) {
    $('.card-link').on('click', function(event) {
        // Allow users to click anywhere on the card to open the post
        var target = $(this).attr('href');
        $('html, body').animate({
            scrollTop: $(target).offset().top
        }, 800);
    });
});

jQuery(function($) {
    var page = 2; // Initial page number
    var loading = false; // Prevent multiple requests at once

    // Load more posts via AJAX when button is clicked
    $('body').on('click', '#rpc-load-more', function() {
        if (loading) return; // Prevent multiple requests
        loading = true;

        var button = $(this);
        var category = rpc_loadmore_params.category;
        var posts_per_page = rpc_loadmore_params.posts_per_page;
        var order_by = rpc_loadmore_params.order_by;
        var layout = rpc_loadmore_params.layout;

        $.ajax({
            url: rpc_loadmore_params.ajax_url,
            type: 'POST',
            data: {
                action: 'rpc_load_more',
                category: category,
                posts_per_page: posts_per_page,
                order_by: order_by,
                layout: layout,
                paged: page
            },
            success: function(response) {
                if (response) {
                    // Append the new posts to the container
                    $('.container .row').append(response);
                    page++; // Increase the page number for next request

                    // Hide or show the "Load More" button based on if there are more posts
                    if (response.trim().length === 0) {
                        button.hide(); // Hide the button if no posts are returned
                    }
                } else {
                    button.hide(); // Hide the button if no response
                }
                loading = false;
            }
        });
    });
});
